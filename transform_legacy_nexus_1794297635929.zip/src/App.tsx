import { BrowserRouter, Routes, Route } from "react-router-dom";
import Layout from "./components/Layout";
import Home from "./pages/Home";
import About from "./pages/About";
import Podcast from "./pages/Podcast";
import InsightfulLight from "./pages/InsightfulLight";
import LegacyWall from "./pages/LegacyWall";
import Contact from "./pages/Contact";
import { Toaster } from "sonner";

function App() {
  return (
    <BrowserRouter>
      <Toaster position="top-right" expand={false} richColors />
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/podcast" element={<Podcast />} />
          <Route path="/insightful-light" element={<InsightfulLight />} />
          <Route path="/legacy-wall" element={<LegacyWall />} />
          <Route path="/contact" element={<Contact />} />
        </Routes>
      </Layout>
    </BrowserRouter>
  );
}
export default App;
