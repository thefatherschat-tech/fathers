import { motion } from "framer-motion";
import { Mail, Phone, MapPin, Instagram, Facebook, Twitter, Youtube, Send } from "lucide-react";

const Contact = () => {
  return (
    <div className="pt-32 pb-24">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center max-w-3xl mx-auto mb-20"
        >
          <h1 className="text-5xl md:text-6xl font-serif font-bold text-primary mb-6">Let's Connect</h1>
          <p className="text-xl text-muted-foreground leading-relaxed">
            The Father's Chat is a platform built around meaningful conversations, mentorship, and transformation. We would love to hear from you.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="space-y-12"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-card p-8 rounded-3xl border border-primary/10 hover:border-primary/30 transition-all">
                <div className="w-14 h-14 bg-primary/10 rounded-2xl flex items-center justify-center text-primary mb-6">
                  <Mail size={28} />
                </div>
                <h3 className="text-xl font-bold mb-2">Email Us</h3>
                <p className="text-muted-foreground">thefatherscha@gmail.com</p>
              </div>

              <div className="bg-card p-8 rounded-3xl border border-primary/10 hover:border-primary/30 transition-all">
                <div className="w-14 h-14 bg-primary/10 rounded-2xl flex items-center justify-center text-primary mb-6">
                  <Phone size={28} />
                </div>
                <h3 className="text-xl font-bold mb-2">Call Us</h3>
                <p className="text-muted-foreground">0797034822</p>
                <p className="text-xs text-primary font-bold mt-1">Available on WhatsApp</p>
              </div>
            </div>

            <div className="bg-card p-8 rounded-3xl border border-primary/10">
              <h3 className="text-2xl font-serif font-bold text-primary mb-8">Follow thefather'schat</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                  { icon: <Instagram />, label: "@thefatherschat", color: "hover:text-pink-500" },
                  { icon: <Facebook />, label: "thefather'schat", color: "hover:text-blue-600" },
                  { icon: <Twitter />, label: "@thefatherschat", color: "hover:text-sky-400" },
                  { icon: <Youtube />, label: "thefather'schat", color: "hover:text-red-600" },
                ].map((social, idx) => (
                  <a
                    key={idx}
                    href="#"
                    className={`flex flex-col items-center p-6 bg-secondary/30 rounded-2xl border border-primary/5 transition-all group ${social.color}`}
                  >
                    <div className="mb-3 transition-transform group-hover:scale-110">
                      {social.icon}
                    </div>
                    <span className="text-sm font-bold opacity-70 group-hover:opacity-100">{social.label}</span>
                  </a>
                ))}
              </div>
            </div>

            <div className="p-8 bg-primary/5 rounded-3xl border border-dashed border-primary/30">
              <p className="text-lg text-foreground/80 italic leading-relaxed text-center">
                "Connecting generations through meaningful conversations, mentorship, and transformative experiences."
              </p>
            </div>
          </motion.div>

          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-card p-10 md:p-12 rounded-[2.5rem] border border-primary/20 shadow-2xl"
          >
            <h3 className="text-3xl font-serif font-bold text-primary mb-10 text-center">Send a Message</h3>
            <form className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-primary uppercase tracking-wider ml-1">First Name</label>
                  <input
                    type="text"
                    placeholder="John"
                    className="w-full bg-secondary/50 border border-primary/10 rounded-xl px-6 py-4 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-primary uppercase tracking-wider ml-1">Last Name</label>
                  <input
                    type="text"
                    placeholder="Doe"
                    className="w-full bg-secondary/50 border border-primary/10 rounded-xl px-6 py-4 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-primary uppercase tracking-wider ml-1">Email Address</label>
                <input
                  type="email"
                  placeholder="john@example.com"
                  className="w-full bg-secondary/50 border border-primary/10 rounded-xl px-6 py-4 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-primary uppercase tracking-wider ml-1">Subject</label>
                <select className="w-full bg-secondary/50 border border-primary/10 rounded-xl px-6 py-4 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all appearance-none">
                  <option>General Inquiry</option>
                  <option>Mentorship Program</option>
                  <option>Podcast Appearance</option>
                  <option>Legacy Wall Submission</option>
                  <option>Partnership</option>
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-primary uppercase tracking-wider ml-1">Your Message</label>
                <textarea
                  rows={5}
                  placeholder="How can we help you on your journey?"
                  className="w-full bg-secondary/50 border border-primary/10 rounded-xl px-6 py-4 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all resize-none"
                ></textarea>
              </div>

              <button
                type="button"
                className="w-full bg-primary text-primary-foreground font-bold py-5 rounded-xl hover:bg-primary/90 transition-all flex items-center justify-center space-x-3 shadow-lg"
              >
                <span>Send Message</span>
                <Send size={20} />
              </button>
            </form>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
