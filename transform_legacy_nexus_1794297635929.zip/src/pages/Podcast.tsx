import { motion } from "framer-motion";
import { Mic, Play, Headphones, Radio, Share2 } from "lucide-react";

const Podcast = () => {
  return (
    <div className="pt-32 pb-24">
      <div className="container mx-auto px-6">
        {/* Header Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center mb-24">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <div className="absolute -inset-4 bg-primary/20 blur-2xl rounded-full opacity-30"></div>
            <img
              src="https://storage.googleapis.com/dala-prod-public-storage/generated-images/cd8c6c8d-f952-43e8-8678-95153a2fe554/podcast-studio-3b09ab42-1781790732641.webp"
              alt="Podcast Studio"
              className="relative w-full h-auto rounded-3xl shadow-2xl border border-primary/20 z-10"
            />
            <div className="absolute bottom-8 right-8 z-20">
              <button className="w-20 h-20 bg-primary text-primary-foreground rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-transform">
                <Play size={32} fill="currentColor" />
              </button>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="inline-flex items-center space-x-2 text-primary font-bold mb-6 tracking-widest uppercase">
              <Mic size={20} />
              <span>Listen & Transform</span>
            </div>
            <h1 className="text-5xl md:text-6xl font-serif font-bold text-foreground mb-8">THE FATHER'S CHAT PODCAST</h1>
            <h2 className="text-2xl font-sans text-primary mb-10 italic">Conversations That Connect, Educate, and Transform</h2>
            
            <div className="space-y-6 text-lg text-muted-foreground leading-relaxed">
              <p>
                The Father's Chat Podcast is a platform created to host meaningful conversations with inspiring individuals, thought leaders, mentors, professionals, and people with impactful stories.
              </p>
              <p>
                Through authentic dialogue and shared experiences, the podcast explores topics around purpose, faith, leadership, family, personal growth, finances, relationships, and the lessons that shape our journey through life.
              </p>
            </div>
          </motion.div>
        </div>

        {/* Philosophy Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-card p-12 md:p-20 rounded-3xl border border-primary/20 mb-24"
        >
          <div className="max-w-4xl mx-auto text-center">
            <h3 className="text-3xl font-serif font-bold text-primary mb-12 uppercase tracking-tight">Our Goal</h3>
            <p className="text-xl md:text-2xl text-foreground leading-relaxed mb-12 italic">
              "Our goal is to create a space where wisdom is shared, experiences are transferred, and every generation can learn from the voices of those who have walked the path before them."
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-left mt-16">
              <div className="space-y-6 text-lg text-muted-foreground">
                <p>
                  From fathers and mentors to leaders, creatives, professionals, and change-makers, The Father's Chat Podcast brings together diverse perspectives that inspire growth, encourage transformation, and strengthen connections across generations.
                </p>
              </div>
              <div className="flex flex-col justify-center items-center md:items-start">
                <p className="text-primary font-bold text-2xl mb-6">
                  Because every story carries a lesson, and every conversation has the potential to impact a generation.
                </p>
                <div className="flex space-x-4">
                  <div className="p-4 bg-primary/10 rounded-xl text-primary"><Headphones size={32} /></div>
                  <div className="p-4 bg-primary/10 rounded-xl text-primary"><Radio size={32} /></div>
                  <div className="p-4 bg-primary/10 rounded-xl text-primary"><Share2 size={32} /></div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Featured Episodes Placeholder */}
        <div>
          <h3 className="text-3xl font-serif font-bold text-primary mb-12 text-center">Listen on Your Favorite Platform</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
            {['Spotify', 'Apple Podcasts', 'Google Podcasts', 'YouTube'].map((platform) => (
              <div key={platform} className="bg-secondary/50 border border-primary/10 p-6 rounded-2xl flex flex-center justify-center items-center hover:bg-primary/10 transition-colors cursor-pointer group">
                <span className="font-bold text-foreground/70 group-hover:text-primary transition-colors">{platform}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Podcast;
