import { motion } from "framer-motion";
import { Lightbulb, BookOpen, Quote, Video, PenTool, Sparkles } from "lucide-react";

const InsightfulLight = () => {
  const sections = [
    {
      title: "Spiritual Growth",
      icon: <Sparkles size={24} />,
      color: "from-amber-400 to-yellow-600"
    },
    {
      title: "Leadership",
      icon: <PenTool size={24} />,
      color: "from-yellow-500 to-amber-700"
    },
    {
      title: "Relationships",
      icon: <BookOpen size={24} />,
      color: "from-amber-600 to-yellow-800"
    },
    {
      title: "Personal Development",
      icon: <Lightbulb size={24} />,
      color: "from-yellow-400 to-amber-600"
    },
    {
      title: "Financial Wisdom",
      icon: <Video size={24} />,
      color: "from-amber-500 to-yellow-700"
    }
  ];

  return (
    <div className="pt-32 pb-24">
      <div className="container mx-auto px-6">
        {/* Hero Section */}
        <div className="relative rounded-[3rem] overflow-hidden bg-background border border-primary/20 mb-24">
          <div className="absolute inset-0">
            <img
              src="https://storage.googleapis.com/dala-prod-public-storage/generated-images/cd8c6c8d-f952-43e8-8678-95153a2fe554/insightful-light-concept-ac2c6d4f-1781790732208.webp"
              alt="Insightful Light"
              className="w-full h-full object-cover opacity-40 scale-110 blur-sm"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-background/40 to-background/95"></div>
          </div>

          <div className="relative z-10 py-24 px-12 text-center max-w-4xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              className="inline-block p-4 bg-primary/20 rounded-full mb-8"
            >
              <Lightbulb className="text-primary" size={48} />
            </motion.div>
            <motion.h1
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="text-5xl md:text-7xl font-serif font-bold text-primary mb-8"
            >
              INSIGHTFUL LIGHT
            </motion.h1>
            <motion.h2
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4 }}
              className="text-2xl md:text-3xl font-sans text-foreground/90 font-medium mb-12"
            >
              Insights That Inspire Growth, Purpose, and Transformation
            </motion.h2>
          </div>
        </div>

        {/* Content Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center mb-32">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-8 text-lg text-foreground/80 leading-relaxed"
          >
            <p>
              Insightful Light is a platform dedicated to sharing meaningful reflections, wisdom, lessons, and conversations that inspire personal growth and purposeful living.
            </p>
            <p>
              Through articles, thought-provoking quotes, videos, and practical insights, Insightful Light explores topics that encourage spiritual growth, leadership, relationships, personal development, financial wisdom, and the lessons that shape our journey.
            </p>
            <p>
              It is a space where ideas are shared, perspectives are challenged, and wisdom is made accessible to inspire individuals across generations.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="bg-card p-12 rounded-[2.5rem] border border-primary/20 relative shadow-2xl"
          >
            <Quote className="text-primary/20 absolute top-8 left-8" size={80} />
            <div className="relative z-10 pt-12">
              <p className="text-2xl md:text-3xl font-serif text-foreground italic leading-relaxed mb-12">
                "Whether through written reflections, powerful quotes, or impactful conversations, Insightful Light seeks to bring clarity, encouragement, and inspiration to those pursuing growth and purpose."
              </p>
              <div className="flex items-center space-x-4 border-t border-primary/10 pt-8">
                <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center text-primary-foreground">
                  <Lightbulb size={24} />
                </div>
                <p className="font-bold text-primary text-xl">
                  Because every insight has the potential to illuminate a path, transform a mindset, and impact a generation.
                </p>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Topics Grid */}
        <div className="text-center mb-16">
          <h3 className="text-4xl font-serif font-bold text-primary mb-16">Areas of Insight</h3>
          <div className="flex flex-wrap justify-center gap-6">
            {sections.map((section, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="bg-secondary/30 backdrop-blur-sm border border-primary/20 px-8 py-6 rounded-2xl flex items-center space-x-4 hover:border-primary/60 transition-all cursor-default"
              >
                <div className="text-primary">{section.icon}</div>
                <span className="font-bold text-foreground/90 uppercase tracking-wider">{section.title}</span>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default InsightfulLight;
