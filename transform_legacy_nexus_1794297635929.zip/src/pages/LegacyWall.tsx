import { motion } from "framer-motion";
import { Shield, Award, Users, Heart, Star, ChevronRight } from "lucide-react";

const LegacyWall = () => {
  return (
    <div className="pt-32 pb-24 bg-[radial-gradient(circle_at_top,_var(--tw-gradient-stops))] from-primary/5 via-background to-background">
      <div className="container mx-auto px-6">
        {/* Page Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center max-w-4xl mx-auto mb-24"
        >
          <div className="inline-flex items-center space-x-2 text-primary font-bold mb-6 tracking-[0.3em] uppercase text-sm">
            <Shield size={16} />
            <span>Honoring Excellence</span>
          </div>
          <h1 className="text-6xl md:text-8xl font-serif font-bold text-primary mb-8 tracking-tight">LEGACY WALL</h1>
          <p className="text-xl md:text-2xl text-muted-foreground leading-relaxed italic">
            "Honoring those who carry the baton, strengthen the present, and prepare the next generation."
          </p>
        </motion.div>

        {/* Tribute Section */}
        <div className="max-w-6xl mx-auto bg-card rounded-[3rem] border border-primary/20 overflow-hidden shadow-2xl">
          <div className="grid grid-cols-1 lg:grid-cols-12">
            <div className="lg:col-span-5 h-[400px] lg:h-auto bg-black/40 flex items-center justify-center">
              <img
                src="https://storage.googleapis.com/dala-prod-public-storage/attachments/e07a3b3e-b3e4-4eea-8887-919768aa7e77/1781791990181_0.png"
                alt="Rev. Stephen & Pastor Janice Kimwele"
                className="w-full h-full object-contain max-h-[600px]"
              />
            </div>
            
            <div className="lg:col-span-7 p-12 md:p-16 lg:p-20 flex flex-col justify-center">
              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
              >
                <div className="flex items-center space-x-2 text-primary mb-6">
                  <Star size={20} fill="currentColor" />
                  <Star size={20} fill="currentColor" />
                  <Star size={20} fill="currentColor" />
                </div>
                <h2 className="text-4xl md:text-5xl font-serif font-bold text-foreground mb-4">Rev. Stephen Kimwele and Pastor Janice Kimwele</h2>
                <div className="flex flex-wrap gap-4 text-primary font-bold mb-12 uppercase tracking-widest text-sm">
                  <span>Spiritual Parents</span>
                  <span className="text-foreground/20">|</span>
                  <span>Senior Pastors, Peniel Christian Church, Kitui Town</span>
                  <span className="text-foreground/20">|</span>
                  <span>Generational Leaders</span>
                </div>

                <div className="space-y-8 text-lg text-foreground/80 leading-relaxed">
                  <p>
                    Rev. Stephen Kimwele and Pastor Janice Kimwele are honored on The Father's Chat Legacy Wall for their dedication to spiritual leadership, mentorship, service, and generational transformation.
                  </p>
                  <p>
                    Serving as the senior pastors of Peniel Christian Church in Kitui Town, they have committed their lives to teaching, discipleship, and raising generations that are established in faith, truth, character, and purpose. Through their ministry, they have nurtured believers, mentored leaders, and championed a foundation of authentic worship, sound doctrine, and spiritual growth.
                  </p>
                  <p className="text-xl font-serif font-bold text-primary italic pt-8 border-t border-primary/10">
                    Together, Rev. Stephen and Pastor Janice Kimwele embody the heart of generational leadership: receiving wisdom, stewarding influence, and intentionally preparing others to carry the baton forward.
                  </p>
                  <p className="font-bold text-foreground text-lg">
                    Their legacy continues through the lives transformed, leaders developed, and generations established to stand with purpose.
                  </p>
                </div>
              </motion.div>
            </div>
          </div>
        </div>

        {/* Footer Quote */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mt-32 text-center"
        >
          <div className="inline-block p-10 bg-primary/5 rounded-[2rem] border border-primary/10">
            <p className="text-2xl md:text-3xl font-serif text-primary italic max-w-3xl">
              "Every generation has a responsibility to build a foundation that empowers and strengthens the next."
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default LegacyWall;
