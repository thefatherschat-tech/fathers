import { motion } from "framer-motion";
import { Users, Target, Shield, Award, CheckCircle2 } from "lucide-react";

const About = () => {
  const coreValues = [
    {
      title: "Connection",
      description: "We believe meaningful relationships between generations are essential for the transfer of wisdom, values, purpose, and legacy.",
      icon: <Users className="text-primary" size={32} />
    },
    {
      title: "Purpose",
      description: "We are committed to helping fathers and their children discover, pursue, and fulfill their unique God-given calling.",
      icon: <Target className="text-primary" size={32} />
    },
    {
      title: "Mentorship",
      description: "We promote intentional guidance, coaching, and the transfer of wisdom that empowers generations to grow and thrive.",
      icon: <Shield className="text-primary" size={32} />
    },
    {
      title: "Transformation",
      description: "We encourage continuous spiritual, emotional, financial, and personal growth that leads to lasting positive change.",
      icon: <Award className="text-primary" size={32} />
    },
    {
      title: "Integrity",
      description: "We uphold honesty, accountability, authenticity, and strong moral character in every aspect of life.",
      icon: <CheckCircle2 className="text-primary" size={32} />
    },
    {
      title: "Leadership",
      description: "We inspire fathers and their children to become servant leaders who positively influence their families, communities, and society.",
      icon: <Target className="text-primary" size={32} />
    },
    {
      title: "Legacy",
      description: "We believe every generation has a responsibility to build a foundation that empowers and strengthens the next.",
      icon: <Award className="text-primary" size={32} />
    }
  ];

  return (
    <div className="pt-32 pb-24">
      <div className="container mx-auto px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center max-w-4xl mx-auto mb-24"
        >
          <h1 className="text-5xl md:text-6xl font-serif font-bold text-primary mb-8">About The Father's Chat</h1>
          <p className="text-xl text-muted-foreground leading-relaxed italic">
            "A transformational movement focused on mentorship, purpose, leadership, generational connection, faith, and legacy."
          </p>
        </motion.div>

        {/* Vision & Mission */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-32">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="bg-card p-12 rounded-3xl border border-primary/20 relative overflow-hidden group"
          >
            <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:opacity-20 transition-opacity">
              <Target size={120} />
            </div>
            <h2 className="text-3xl font-serif font-bold text-primary mb-6">Vision</h2>
            <p className="text-lg text-foreground leading-relaxed">
              To build a legacy of connected generations where fathers intentionally mentor, guide, and empower their sons and daughters, creating a continuous cycle of purpose, mentorship, transformation, leadership, and impact.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="bg-card p-12 rounded-3xl border border-primary/20 relative overflow-hidden group"
          >
            <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:opacity-20 transition-opacity">
              <Users size={120} />
            </div>
            <h2 className="text-3xl font-serif font-bold text-primary mb-6">Mission</h2>
            <p className="text-lg text-foreground leading-relaxed">
              To connect fathers and their children through meaningful conversations, mentorship, and transformative experiences that nurture purpose, strengthen character, promote holistic growth, and equip generations to lead with integrity and impact.
            </p>
          </motion.div>
        </div>

        {/* Core Values */}
        <div className="mb-32">
          <h2 className="text-4xl font-serif font-bold text-center text-primary mb-16">Core Values</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {coreValues.map((value, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="bg-card p-8 rounded-2xl border border-primary/10 hover:border-primary/40 transition-all"
              >
                <div className="mb-6">{value.icon}</div>
                <h3 className="text-2xl font-serif font-bold text-foreground mb-4">{value.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{value.description}</p>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Why The Father's Chat? */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="bg-primary/5 p-12 md:p-20 rounded-3xl border border-primary/20"
        >
          <h2 className="text-4xl font-serif font-bold text-primary mb-12 text-center">WHY THE FATHER'S CHAT?</h2>
          <div className="max-w-4xl mx-auto space-y-8 text-lg text-foreground leading-relaxed">
            <p>
              The Father's Chat was birthed from a deep conviction about the importance of generational connection and the responsibility we have to intentionally invest in those coming after us.
            </p>
            <p>
              We believe that fathering is more than a title or a position; it is also an action. To father is to nurture, guide, mentor, protect, and empower another person toward purpose. While fathers often carry this responsibility within families, the impact of fathering extends beyond biology—because men and women alike have played significant roles in shaping, mentoring, and raising generations.
            </p>
            <p>
              Life is a journey of stewardship. It is like a relay race where victory is not achieved by one person running alone, but by each generation faithfully carrying and passing on the baton. Those ahead are called to run with wisdom, purpose, and excellence while preparing the next generation to receive, carry, and advance what has been entrusted to them.
            </p>
            <p className="font-bold text-primary text-xl">
              The challenge is not only running the race, but ensuring that the baton is transferred.
            </p>
            <p>
              When generations become disconnected, wisdom, values, experiences, and opportunities can be lost. This affects individuals, families, communities, and the ability to fully walk in purpose.
            </p>
            <p>
              The Father's Chat exists to create spaces where intentional connections are built—where biological fathers connect with their children, spiritual fathers and mothers invest in the next generation, and leaders create pathways for others to grow, inherit wisdom, and carry forward impact.
            </p>
            <p>
              We believe every generation has something to receive and something to give. Fathers, mentors, leaders, and individuals with influence all have a role in shaping the future.
            </p>
            <p>
              Through meaningful conversations, mentorship, and transformation, The Father's Chat seeks to bridge generations, strengthen relationships, and create a continuous transfer of purpose, wisdom, and legacy.
            </p>
            <p className="font-bold text-primary text-xl text-center pt-8">
              Because when generations connect, wisdom is preserved, purpose is advanced, and legacies are built.
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default About;
