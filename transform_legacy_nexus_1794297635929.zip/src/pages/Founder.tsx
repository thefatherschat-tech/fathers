import { motion } from "framer-motion";
import { Award, Music, BookOpen, Heart } from "lucide-react";

const Founder = () => {
  return (
    <div className="pt-32 pb-24">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
          {/* Image Side */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="lg:sticky lg:top-32"
          >
            <div className="relative">
              <div className="absolute -inset-4 border-2 border-primary/20 rounded-3xl -z-10 translate-x-4 translate-y-4"></div>
              <img
                src="https://storage.googleapis.com/dala-prod-public-storage/attachments/e07a3b3e-b3e4-4eea-8887-919768aa7e77/1781865230891_gggggggggggggggggggg.png"
                alt="Febechi Njenga"
                className="w-full h-auto rounded-3xl shadow-2xl border border-primary/10"
              />
            </div>
            
            <div className="mt-12 grid grid-cols-2 gap-6">
              <div className="bg-card p-6 rounded-2xl border border-primary/10">
                <Award className="text-primary mb-4" size={28} />
                <h4 className="font-bold text-lg mb-2">Academic</h4>
                <p className="text-sm text-muted-foreground">BSc. Economics & Statistics, CPA</p>
              </div>
              <div className="bg-card p-6 rounded-2xl border border-primary/10">
                <Music className="text-primary mb-4" size={28} />
                <h4 className="font-bold text-lg mb-2">Creative</h4>
                <p className="text-sm text-muted-foreground">Worship Leader, Songwriter, Pianist</p>
              </div>
            </div>
          </motion.div>

          {/* Content Side */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="flex flex-col lg:pl-12"
          >
            <h1 className="text-5xl md:text-6xl font-serif font-bold text-primary mb-4 lg:sticky lg:top-0 lg:bg-background lg:pt-8 lg:pb-4 lg:z-10">Febechi Njenga</h1>
            <h2 className="text-2xl font-sans font-medium text-foreground/80 mb-12">Founder of The Father's Chat</h2>

            <div className="space-y-8 text-lg text-foreground/90 leading-relaxed">
              <p>
                Febechi Njenga is the Founder of The Father's Chat, a transformational platform dedicated to connecting generations through meaningful conversations, mentorship, and holistic development.
              </p>
              <p>
                He holds a Bachelor of Science in Economics and Statistics and is a Certified Public Accountant (CPA), bringing together analytical expertise, leadership, and practical insight in areas of personal growth, financial empowerment, purpose, and family development.
              </p>
              <p>
                Beyond his professional background, Febechi is a mentor, worship leader, singer-songwriter, and pianist who is passionate about sharing wisdom, inspiring transformation, and helping individuals discover their God-given purpose.
              </p>
              <p>
                The Father's Chat was inspired by a deep conviction about the importance of intentional relationships, meaningful conversations, and the role fathers play in shaping the lives and futures of their children. Through his own journey and experiences, Febechi developed a passion for creating spaces where fathers and children can connect, learn, grow, and build stronger relationships.
              </p>
              <p>
                Through The Father's Chat, he seeks to encourage fathers to embrace mentorship, leadership, and intentional engagement while empowering sons and daughters to discover purpose, develop character, and pursue meaningful lives.
              </p>
              <p className="font-bold text-primary italic">
                Febechi believes that when generations are connected, wisdom is transferred, families are strengthened, and communities are transformed.
              </p>
            </div>

            <div className="mt-16 p-10 bg-primary/5 rounded-3xl border border-primary/10">
              <h3 className="text-2xl font-serif font-bold text-primary mb-6 flex items-center space-x-3">
                <Heart size={24} />
                <span>Our Philosophy</span>
              </h3>
              <p className="text-lg text-muted-foreground italic leading-relaxed">
                "Intentional relationships and meaningful conversations are the cornerstones of a legacy that lasts."
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Founder;
