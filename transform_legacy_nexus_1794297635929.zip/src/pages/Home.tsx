import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { ArrowRight, Mic, BookOpen, Users, Award, Shield, Target } from "lucide-react";

const Home = () => {
  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="relative h-[90vh] flex items-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src="https://storage.googleapis.com/dala-prod-public-storage/generated-images/cd8c6c8d-f952-43e8-8678-95153a2fe554/hero-home-8b093bd4-1781790733017.webp"
            alt="Fathers and children connecting"
            className="w-full h-full object-cover opacity-60"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-background via-background/80 to-transparent"></div>
        </div>

        <div className="container mx-auto px-6 relative z-10">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-3xl"
          >
            <h1 className="text-5xl md:text-7xl font-serif font-bold text-foreground mb-6 leading-tight">
              A Legacy of <span className="text-primary">Connected Generations</span>
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground mb-10 leading-relaxed">
              Where fathers intentionally mentor, guide, and empower their sons and daughters, creating a continuous cycle of purpose and impact.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link
                to="/about"
                className="bg-primary text-primary-foreground px-8 py-4 rounded-full font-bold flex items-center justify-center space-x-2 hover:bg-primary/90 transition-all"
              >
                <span>Join the Movement</span>
                <ArrowRight size={20} />
              </Link>
              <Link
                to="/podcast"
                className="bg-secondary text-secondary-foreground border border-primary/20 px-8 py-4 rounded-full font-bold flex items-center justify-center space-x-2 hover:bg-secondary/80 transition-all"
              >
                <Mic size={20} />
                <span>Listen to the Podcast</span>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Intro Sections */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="bg-card p-8 rounded-2xl border border-primary/10 hover:border-primary/30 transition-all group">
              <div className="w-14 h-14 bg-primary/10 rounded-xl flex items-center justify-center text-primary mb-6 group-hover:bg-primary group-hover:text-primary-foreground transition-all">
                <Mic size={28} />
              </div>
              <h3 className="text-2xl font-serif font-bold mb-4">The Podcast</h3>
              <p className="text-muted-foreground mb-6">
                Conversations that connect, educate, and transform. Host meaningful dialogues with thought leaders and mentors.
              </p>
              <Link to="/podcast" className="text-primary font-bold inline-flex items-center space-x-2">
                <span>Listen Now</span>
                <ArrowRight size={16} />
              </Link>
            </div>

            <div className="bg-card p-8 rounded-2xl border border-primary/10 hover:border-primary/30 transition-all group">
              <div className="w-14 h-14 bg-primary/10 rounded-xl flex items-center justify-center text-primary mb-6 group-hover:bg-primary group-hover:text-primary-foreground transition-all">
                <BookOpen size={28} />
              </div>
              <h3 className="text-2xl font-serif font-bold mb-4">Insightful Light</h3>
              <p className="text-muted-foreground mb-6">
                Insights that inspire growth, purpose, and transformation through articles, quotes, and reflections.
              </p>
              <Link to="/insightful-light" className="text-primary font-bold inline-flex items-center space-x-2">
                <span>Explore Insights</span>
                <ArrowRight size={16} />
              </Link>
            </div>

            <div className="bg-card p-8 rounded-2xl border border-primary/10 hover:border-primary/30 transition-all group">
              <div className="w-14 h-14 bg-primary/10 rounded-xl flex items-center justify-center text-primary mb-6 group-hover:bg-primary group-hover:text-primary-foreground transition-all">
                <Users size={28} />
              </div>
              <h3 className="text-2xl font-serif font-bold mb-4">Legacy Wall</h3>
              <p className="text-muted-foreground mb-6">
                Honoring those who carry the baton, strengthen the present, and prepare the next generation.
              </p>
              <Link to="/legacy-wall" className="text-primary font-bold inline-flex items-center space-x-2">
                <span>View Tributes</span>
                <ArrowRight size={16} />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Core Values Preview */}
      <section className="py-24 bg-secondary/30 border-y border-primary/10">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-4xl font-serif font-bold text-primary mb-16">Our Core Values</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-8">
            {[
              { icon: <Users />, label: "Connection" },
              { icon: <Target />, label: "Purpose" },
              { icon: <Shield />, label: "Mentorship" },
              { icon: <Award />, label: "Transformation" },
              { icon: <Shield />, label: "Integrity" },
              { icon: <Target />, label: "Leadership" },
              { icon: <Award />, label: "Legacy" },
            ].map((value, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="flex flex-col items-center"
              >
                <div className="w-16 h-16 rounded-full border border-primary/30 flex items-center justify-center text-primary mb-4">
                  {value.icon}
                </div>
                <span className="font-bold text-sm uppercase tracking-wider">{value.label}</span>
              </motion.div>
            ))}
          </div>
          <div className="mt-16">
            <Link
              to="/about"
              className="text-primary font-bold border-b-2 border-primary hover:text-foreground hover:border-foreground transition-all pb-1"
            >
              Learn More About Our Mission
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
